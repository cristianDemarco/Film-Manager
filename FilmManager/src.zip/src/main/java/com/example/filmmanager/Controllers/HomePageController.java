package com.example.filmmanager.Controllers;

import com.example.filmmanager.Controller;
import com.example.filmmanager.ScenesData;
import com.example.filmmanager.Validator;
import javafx.fxml.FXML;
import javafx.event.ActionEvent;

import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import java.io.IOException;

public class HomePageController extends Controller {
    @FXML
    private TextField tf_filmCode;

    @FXML
    private Label lbl_error;

    @FXML
    public void insert(ActionEvent actionEvent) throws IOException {
        if(isCodeValid()){
            System.out.println(findFilm(tf_filmCode.getText()));
            if(findFilm(tf_filmCode.getText()) == null){
                InsertController.filmCode = tf_filmCode.getText();
                changeScene(ScenesData.InsertPage.getScene(), actionEvent);
            } else {
                lbl_error.setText("Film già registrato");
            }
        }
    }

    @FXML
    public void visualize(ActionEvent actionEvent) throws IOException {
        if(isCodeValid()){
            String filmLine = findFilm(tf_filmCode.getText());
            // Visualizzazione solo se il film è già registrato
            if(filmLine != null){
                lbl_error.setText("");
                VisualizeController.record=filmLine;
                changeScene(ScenesData.VisualizePage.getScene(), actionEvent);
            } else {
                lbl_error.setText("Film non presente in archivio");
            }
        }
    }

    public boolean isCodeValid(){
        String filmCode = tf_filmCode.getText();
        if(filmCode.isEmpty()){
            lbl_error.setText("Codice non valorizzato");
            return false;
        }
        if(filmCode.length() != 8){
            lbl_error.setText("Il codice deve essere di 8 cifre");
            return false;
        }

        if(!Validator.isNumeric(filmCode)){
            lbl_error.setText("Il codice deve essere numerico");
            return false;
        }
        return true;
    }
}