package com.example.filmmanager;

public class SceneData {
    public String title;
    public String path;

    public SceneData(String title, String path) {
        this.title = title;
        this.path = path;
    }
}
