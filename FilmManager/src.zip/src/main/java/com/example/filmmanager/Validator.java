package com.example.filmmanager;

public class Validator {
    static public boolean isNumeric(String str){
        try{
            Integer.parseInt(str);
            return true;
        } catch (Exception e){
            return false;
        }
    }
}
